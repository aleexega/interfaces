/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JSwing;

import java.awt.Panel;
import javax.swing.JPanel;

/**
 *
 * @author FP
 */
public class JSwing {

    public static void main(String[] args) {

        Ventana ventana = new Ventana();
        ventana.Panel();
        JPanel panel=new JPanel();
        //si tenemos boton.setBounds( 50,120,200, 50);
        //el primer es distancia desde la izquierda, el segundo distancia de arriba
        //el tercero de ancho y el cuarto de alto
    }
}
